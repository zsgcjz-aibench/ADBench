import torch
from torch import nn
from torch.utils.data import Dataset

import os
import numpy as np
from sklearn import metrics
from tqdm import trange
import utilities as UT
import skimage.transform as skTrans
import random
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve, auc
import random
import eval_index_cal as evindex
import copy
import pandas as pd
import torch.nn.functional as F

def prep_data(LABEL_PATH, TEST_NUM):
    # This function is used to prepare train/test labels for 5-fold cross-validation
    TEST_LABEL = LABEL_PATH + '/fold_' + str(TEST_NUM) + '.csv'

    # combine train labels
    filenames = [LABEL_PATH + '/fold_0.csv',
                 LABEL_PATH + '/fold_1.csv',
                 LABEL_PATH + '/fold_2.csv',
                 LABEL_PATH + '/fold_3.csv',
                 LABEL_PATH + '/fold_4.csv', ]

    filenames.remove(TEST_LABEL)

    with open(LABEL_PATH + '/combined_train_list.csv', 'w') as combined_train_list:
        for fold in filenames:
            for line in open(fold, 'r'):
                combined_train_list.write(line)
    TRAIN_LABEL = LABEL_PATH + '/combined_train_list.csv'

    return TRAIN_LABEL, TEST_LABEL


class Dataset_Early_Fusion(Dataset):
    def __init__(self,filepath,
                 label_file):
        # self.files = UT.read_csv(label_file)
        self.ridlist, self.viscode_list, self.Data_list, self.Label_list = UT.read_csv_2(label_file)
        # print("self.files:", self.Data_list)
        self.filepaths = filepath

    def __len__(self):
        return len(self.Data_list)

    def __getitem__(self, idx):
        rid = self.ridlist[idx]
        viscode = self.viscode_list[idx]

        label = self.Label_list[idx]

        full_path = self.Data_list[idx]

        # im = np.load(self.filepaths + full_path + '.npy')
        im = np.load(self.filepaths + full_path + '.npy')  # (110, 110, 110)
        im = skTrans.resize(im, (110, 110, 110), order=1, preserve_range=True)
        # print("im.shape:", im.shape)  # (110, 110, 110)
        # im = np.array(im)
        im = np.reshape(im, (1, 110, 110, 110))  # (1, 110, 110, 110)

        return im, label, full_path, rid, viscode  # output image shape [T,C,W,H]


        # return im, int(label), full_path  # output image shape [T,C,W,H]




class VGG3D(nn.Module):
    def __init__(self, num_classes=2,
                 input_shape=(1, 110, 110, 110)):  # input: input_shape:	[num_of_filters, kernel_size] (e.g. [256, 25])
        super(VGG3D, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv3d(
                in_channels=input_shape[0],  # input height
                out_channels=8,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),

            nn.Conv3d(
                in_channels=8,  # input height
                out_channels=8,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),  # activation

            nn.MaxPool3d(kernel_size=(2, 2, 2), stride=2)  # choose max value in 2x2 area
        )

        self.conv2 = nn.Sequential(
            nn.Conv3d(
                in_channels=8,  # input height
                out_channels=16,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),
            nn.Conv3d(
                in_channels=16,  # input height
                out_channels=16,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),  # activation
            nn.MaxPool3d(kernel_size=(2, 2, 2), stride=2)  # choose max value in 2x2 area
        )

        self.conv3 = nn.Sequential(
            nn.Conv3d(
                in_channels=16,  # input height
                out_channels=32,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),
            nn.Conv3d(
                in_channels=32,  # input height
                out_channels=32,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),  # activation
            nn.Conv3d(
                in_channels=32,  # input height
                out_channels=32,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),
            nn.MaxPool3d(kernel_size=(2, 2, 2), stride=2)  # choose max value in 2x2 area
        )

        self.conv4 = nn.Sequential(
            nn.Conv3d(
                in_channels=32,  # input height
                out_channels=64,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),
            nn.Conv3d(
                in_channels=64,  # input height
                out_channels=64,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),  # activation
            nn.Conv3d(
                in_channels=64,  # input height
                out_channels=64,  # n_filters
                kernel_size=(3, 3, 3),  # filter size
                padding=1
            ),
            nn.ReLU(),
            nn.MaxPool3d(kernel_size=(2, 2, 2), stride=2)  # choose max value in 2x2 area
        )

        fc1_output_features = 128
        self.fc1 = nn.Sequential(
            nn.Linear(13824, 128),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        fc2_output_features = 64
        self.fc2 = nn.Sequential(
            nn.Linear(fc1_output_features, fc2_output_features),
            nn.BatchNorm1d(fc2_output_features),
            nn.ReLU()
        )

        if (num_classes == 2):
            # 未修改前
            self.out = nn.Linear(fc2_output_features, 2)
            self.out_act = nn.Sigmoid()
            # 修改后
            # self.out1 = nn.Linear(fc2_output_features, 1)
            # self.out2 = nn.Linear(fc2_output_features, 1)
            # self.out_act = nn.Sigmoid()
        else:
            self.out = nn.Linear(fc2_output_features, num_classes)
            self.out_act = nn.Softmax()

    def forward(self, x, drop_prob=0.8):

        x = self.conv1(x)
        #		print(x.shape)
        x = self.conv2(x)
        #		print(x.shape)
        x = self.conv3(x)
        #		print(x.shape)
        x = self.conv4(x)
        #		print(x.shape)
        x = x.view(x.size(0), -1)  # flatten the output of conv2 to (batch_size, num_filter * w * h)
        #		print(x.shape)
        x = self.fc1(x)
        x = nn.Dropout(drop_prob)(x)
        x = self.fc2(x)
        # x = nn.Dropout(drop_prob)(x)
        #close setting
        x = self.out(x)  # probability
        prob = self.out_act(x)  # probability
        # ovrns setting
        # out1 = self.out1(x)
        # out2 = self.out2(x)
        # out3 = torch.cat((out1, out2), dim=1)
        # prob = self.out_act(out3)  # probability

        prob = prob.to(torch.float)
        # out3 = out3.to(torch.float)

        # 		y_hat = self.out_act(prob) # label
        # 		return y_hat, prob, x    # return x for visualization
        # return prob, out3

        return prob


def train(train_dataloader, val_dataloader, i):
    net = VGG3D().to(device)

    opt = torch.optim.Adam(net.parameters(), lr=LR, weight_decay=0.0)
    #     opt = torch.optim.SGD(net.parameters(), lr=LR, momentum=0.9)
    scheduler = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.985)
    #     scheduler = torch.optim.lr_scheduler.CyclicLR(opt,
    #                                                   base_lr=LR,
    #                                                   max_lr=0.001,
    #                                                   step_size_up=100,
    #                                                   cycle_momentum=False)
    # loss_fcn = torch.nn.CrossEntropyLoss(weight=LOSS_WEIGHTS.to(device))

    t = trange(EPOCHS, desc=' ', leave=True)

    train_hist = []
    val_hist = []
    pred_result = []
    old_acc = 0
    old_auc = 0
    test_acc = 0
    best_epoch = 0
    test_performance = []
    for e in t:
        y_true = []
        y_pred = []
        y_pred_no_sig = []
        y_true1 = []
        ridlist = []
        viscodelist = []

        val_y_true = []
        val_y_pred = []
        val_y_no_sig = []
        val_ridlist = []
        val_viscodelist = []

        train_loss = 0
        val_loss = 0

        # training
        net.train()
        # for step, (img, label, _) in enumerate(train_dataloader):
        for step, (img, label, _, rid, viscode) in enumerate(train_dataloader):
            img = img.float().to(device)
            label = label.long().to(device)
            label = F.one_hot(label.to(torch.int64), num_classes=2).float()

            rid = rid.long().to(device)
            viscode = np.array(viscode, dtype=str)
            rid = rid.cpu().detach()
            rid = np.array(rid)
            
            opt.zero_grad()
            out = net(img)
            # out, no_sig = net(img)

            # loss = loss_fcn(out, label)
            loss = F.binary_cross_entropy(out, label)

            loss.backward()
            opt.step()

            label = label.cpu().detach()
            out = out.cpu().detach()
            # no_sig = no_sig.cpu().detach()

            y_true, y_pred = UT.assemble_labels(step, y_true, y_pred, label, out)

            # y_true1, y_pred_no_sig = UT.assemble_labels(step, y_true1, y_pred_no_sig, label, no_sig)

            train_loss += loss.item()

            for ridline in rid:
                ridlist.append(ridline)
            for viscodeline in viscode:
                viscodelist.append(viscodeline)

        train_loss = train_loss / (step + 1)
        acc = float(torch.sum(torch.max(y_pred, 1)[1] == y_true[:, 1])) / float(len(y_pred))
        auc = metrics.roc_auc_score(y_true[:, 1], y_pred[:, 1])
        f1 = metrics.f1_score(y_true[:, 1], torch.max(y_pred, 1)[1])
        precision = metrics.precision_score(y_true[:, 1], torch.max(y_pred, 1)[1])
        recall = metrics.recall_score(y_true[:, 1], torch.max(y_pred, 1)[1])
        ap = metrics.average_precision_score(y_true[:, 1], torch.max(y_pred, 1)[1])  # average_precision

        if not os.path.exists("./modelsave/close"):
            os.makedirs("./modelsave/close")
        torch.save(net.state_dict(),
                   "./modelsave/close/" + str(e) + "_" + 'VGG_VoxCNN_normal.pth')

        scheduler.step()


        train_y_pred = np.array(y_pred)
        train_y_true = np.array(y_true)



        save_result = []
        # save_label = []
        for index in range(0, len(train_y_true)):
            save_result.append([ridlist[index], viscodelist[index], train_y_pred[index, 0], train_y_pred[index, 1],
                                train_y_true[index, 0],train_y_true[index, 1]])

        save_result = pd.DataFrame(save_result)
        save_path = './close_train_valid_preds/close/epoch_' + str(
            e) + '_VoxCNN_ResNet_ac_train_result.csv'

        save_result.to_csv(save_path, index=0,
                           header=['rid', 'viscode', 'cn_pred', 'ad_pred','cn_label', 'ad_label'])


        # val
        net.eval()
        full_path = []
        y_pred_no_sig = []
        y_true1 = []
        with torch.no_grad():
            # for step, (img, label, _) in enumerate(val_dataloader):
            for step, (img, label, _, rid, viscode) in enumerate(val_dataloader):
                img = img.float().to(device)
                label = label.long().to(device)
                label = F.one_hot(label.to(torch.int64), num_classes=2).float()

                rid = rid.long().to(device)
                viscode = np.array(viscode, dtype=str)
                rid = rid.cpu().detach()
                rid = np.array(rid)

                out = net(img)
                # out, no_sig = net(img)

                # loss = loss_fcn(out, label)
                loss = F.binary_cross_entropy(out, label)

                val_loss += loss.item()

                label = label.cpu().detach()
                out = out.cpu().detach()
                # no_sig = no_sig.cpu().detach()

                val_y_true, val_y_pred = UT.assemble_labels(step, val_y_true, val_y_pred, label, out)

                for item in _:
                    full_path.append(item)

                for ridline in rid:
                    val_ridlist.append(ridline)
                for viscodeline in viscode:
                    val_viscodelist.append(viscodeline)

        val_loss = val_loss / (step + 1)
        val_acc = float(torch.sum(torch.max(val_y_pred, 1)[1] == val_y_true[:, 1])) / float(len(val_y_pred))
        val_auc = metrics.roc_auc_score(val_y_true[:, 1], val_y_pred[:, 1])
        val_f1 = metrics.f1_score(val_y_true[:, 1], torch.max(val_y_pred, 1)[1])
        val_precision = metrics.precision_score(val_y_true[:, 1], torch.max(val_y_pred, 1)[1])
        val_recall = metrics.recall_score(val_y_true[:, 1], torch.max(val_y_pred, 1)[1])
        val_ap = metrics.average_precision_score(val_y_true[:, 1], torch.max(val_y_pred, 1)[1])  # average_precision

        train_hist.append([train_loss, acc, auc, f1, precision, recall, ap])
        val_hist.append([val_loss, val_acc, val_auc, val_f1, val_precision, val_recall, val_ap])

        t.set_description("Epoch: %i, train loss: %.4f, train acc: %.4f, val loss: %.4f, val acc: %.4f, test acc: %.4f"
                          % (e, train_loss, acc, val_loss, val_acc, test_acc))

        if (old_acc < val_acc):
            if not os.path.exists("./modelsave/close"):
                os.makedirs("./modelsave/close")
            torch.save(net.state_dict(),
                       "./modelsave/close/" + str(e) + "_" + 'VGG_VoxCNN_best.pth')
            old_acc = val_acc
            old_auc = val_auc
            best_epoch = e
            test_loss = 0
            test_y_true = val_y_true
            test_y_pred = val_y_pred

            test_loss = val_loss
            test_acc = float(torch.sum(torch.max(test_y_pred, 1)[1] == test_y_true[:, 1])) / float(len(test_y_pred))
            test_auc = metrics.roc_auc_score(test_y_true[:, 1], test_y_pred[:, 1])
            test_f1 = metrics.f1_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])
            test_precision = metrics.precision_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])
            test_recall = metrics.recall_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])
            test_ap = metrics.average_precision_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])  # average_precision

        if (old_acc == val_acc) and (old_auc < val_auc):
            if not os.path.exists("./modelsave/close"):
                os.makedirs("./modelsave/close")
            torch.save(net.state_dict(),
                       "./modelsave/close/" + str(e) + "_" + 'VGG_VoxCNN_best.pth')
            old_acc = val_acc
            old_auc = val_auc
            best_epoch = e
            test_loss = 0
            test_y_true = val_y_true
            test_y_pred = val_y_pred

            test_loss = val_loss
            test_acc = float(torch.sum(torch.max(test_y_pred, 1)[1] == test_y_true[:, 1])) / float(len(test_y_pred))
            test_auc = metrics.roc_auc_score(test_y_true[:, 1], test_y_pred[:, 1])
            test_f1 = metrics.f1_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])
            test_precision = metrics.precision_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])
            test_recall = metrics.recall_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])
            test_ap = metrics.average_precision_score(test_y_true[:, 1], torch.max(test_y_pred, 1)[1])  # average_precision

            test_performance = [best_epoch, test_loss, test_acc, test_auc, test_f1, test_precision, test_recall,
                                test_ap]



        val_y_pred = np.array(val_y_pred)
        val_y_true = np.array(val_y_true)


        save_result = []

        for index in range(0, len(val_y_true)):
            save_result.append([val_ridlist[index], val_viscodelist[index], val_y_pred[index, 0], val_y_pred[index, 1],
                                val_y_true[index, 0], val_y_true[index, 1]])

        save_result = pd.DataFrame(save_result)
        save_path = './close_train_valid_preds/close/epoch_' + str(e) + '_VoxCNN_ResNet_ac_valid_result.csv'
        save_result.to_csv(save_path, index=0,
                           header=['rid', 'viscode', 'cn_pred', 'ad_pred','cn_label', 'ad_label'])

    return train_hist, val_hist, test_performance, test_y_true, test_y_pred, full_path


def test(test_dataloader, feature='Vgg11'):
    test_hist = []
    # loss_fcn = torch.nn.CrossEntropyLoss(weight=LOSS_WEIGHTS.to(device))
    test_y_true = []
    test_y_pred = []
    test_ridlist = []
    test_viscodelist = []
    y_pred_no_sig = []
    y_true1 = []

    test_loss = 0
    net = VGG3D().to(device)
    net.load_state_dict(
        torch.load("./modelsave/close/50_VGG_VoxCNN_best.pth"))  # ///////////
    net.eval()
    with torch.no_grad():
        # for step, (img, label, _) in enumerate(test_dataloader):
        for step, (img, label, _, rid, viscode) in enumerate(test_dataloader):
            img = img.float().to(device)
            label = label.long().to(device)
            label = F.one_hot(label.to(torch.int64), 2).float()

            rid = rid.long().to(device)
            viscode = np.array(viscode, dtype=str)
            rid = rid.cpu().detach()
            rid = np.array(rid)

            out = net(img)
            # out, no_sig = net(img)

            # net_2 = nn.Softmax(dim=1)
            # out = net_2(out)

            label = label.cpu().detach()
            out = out.cpu().detach()
            # no_sig = no_sig.cpu().detach()

            test_y_true, test_y_pred = UT.assemble_labels(step, test_y_true, test_y_pred, label, out)
            # y_true1, y_pred_no_sig = UT.assemble_labels(step, y_true1, y_pred_no_sig, label, no_sig)

            for ridline in rid:
                test_ridlist.append(ridline)
            for viscodeline in viscode:
                test_viscodelist.append(viscodeline)

    preds = np.array(test_y_pred)
    labels = np.array(test_y_true)



    # evindex.cal_CI_plot(preds, labels[:, 1])  #open setting plot
    evindex.cal_CI_plot_close3(preds, labels[:, 1]) #close setting plot
    


    save_result = []

    for index in range(0, len(labels)):
        save_result.append([test_ridlist[index], test_viscodelist[index], preds[index, 0], preds[index, 1],
                            labels[index, 0], labels[index, 1]])

    save_result = pd.DataFrame(save_result)
    save_path = './close_train_valid_preds/openmax/VoxCNN_ResNet_ac_test_preds.csv'

    save_result.to_csv(save_path, index=0,
                       header=['rid', 'viscode', 'cn_pred', 'ad_pred', 'cn_label','ad_label'])


features_in_hook = []
features_out_hook = []


def hook(module, fea_in, fea_out):
    fea_in_np = fea_in[0].cpu().numpy()
    features_in_hook.append(fea_in_np)

    fea_out_np = list(fea_out[0].cpu().numpy())
    features_out_hook.append(fea_out_np)
    return None

def get_av_softmax(test_loader, layer_name):
    net = VGG3D().to(device)
    net.load_state_dict(torch.load('./modelsave/close/50_VGG_VoxCNN_best.pth'))
    # net.cuda()
    for (name, module) in net.named_modules():
        print(name)
        if name == layer_name:
            module.register_forward_hook(hook=hook)




if __name__ == '__main__':

    GPU = 0
    BATCH_SIZE = 5
    EPOCHS = 150

    LR = 0.000027
    LOSS_WEIGHTS = torch.tensor([1., 1.])

    device = torch.device('cuda:' + str(GPU) if torch.cuda.is_available() else 'cpu')


    train_hist = []
    val_hist = []
    test_performance = []
    test_y_true = np.asarray([])
    test_y_pred = np.asarray([])
    full_path = np.asarray([])
    trainlabel_file = './csv/train.csv'
    validlabel_file = './csv/valid.csv'
    testlabel_file = './csv/test.csv'
    open_testlabel_file = './csv/open_test.csv'
    filepath = '/home/lxs/ADNI/npy/'  #Path for storing npy




    test_dataset = Dataset_Early_Fusion(filepath=filepath, label_file=testlabel_file)
    test_dataloader = torch.utils.data.DataLoader(test_dataset, num_workers=1, batch_size=BATCH_SIZE, shuffle=False,
                                                  drop_last=True)


    print("----------------- start--------------")
    test(test_dataloader)
    print("------------------test end---------------")

    print("----------------- start--------------")
    layer_name = 'out'
    get_av_softmax(test_dataloader, layer_name)
    print("----------------- finish!!!--------------")




