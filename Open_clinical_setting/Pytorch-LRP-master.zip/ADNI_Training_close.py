#!/usr/bin/env python
# coding: utf-8

import glob
import h5py
import os
import sys
import time
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# pytorch
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler

# sklearn functions
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, KFold, GroupShuffleSplit

# load functions from nitorch
from nitorch.data import load_nifti
from nitorch.transforms import ToTensor, SagittalTranslate, SagittalFlip, \
                                AxialTranslate, normalization_factors, Normalize, \
                                IntensityRescale
from nitorch.callbacks import EarlyStopping, ModelCheckpoint
from nitorch.trainer import Trainer
from nitorch.initialization import weights_init
from nitorch.metrics import balanced_accuracy, sensitivity, specificity
from nitorch.utils import count_parameters
#import torchio as tio
from npy_load_data import ImageDataset
from scipy import stats
from sklearn.metrics import roc_auc_score
import eval_index_cal as evindex
from sklearn.metrics import roc_curve, auc
import random
import matplotlib.pyplot as plt


#加载参数，设置全局变量
from settings import settings
for k in settings.keys():
    print("Adding " + k + " to namespace")
    globals()[k] = settings[k]


torch.__version__

gpu = 0
b = 4 #banch_size
num_classes = 2

dtype = np.float64





train_h5_ = './csv/train.csv'  
val_h5_ = './csv/valid.csv'      
holdout_h5_ = './csv/test.csv'  

adni_data_train = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=train_h5_)
adni_data_val = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=val_h5_)
adni_data_test = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=holdout_h5_)




class ClassificationModel3D(nn.Module):
    """The model we use in the paper."""

    def __init__(self, dropout=0.4, dropout2=0.4):
        nn.Module.__init__(self)
        self.Conv_1 = nn.Conv3d(1, 8, 3)
        self.Conv_1_bn = nn.BatchNorm3d(8)
        self.Conv_1_mp = nn.MaxPool3d(2)
        self.Conv_2 = nn.Conv3d(8, 16, 3)
        self.Conv_2_bn = nn.BatchNorm3d(16)
        self.Conv_2_mp = nn.MaxPool3d(3)
        self.Conv_3 = nn.Conv3d(16, 32, 3)
        self.Conv_3_bn = nn.BatchNorm3d(32)
        self.Conv_3_mp = nn.MaxPool3d(2)
        self.Conv_4 = nn.Conv3d(32, 64, 3)
        self.Conv_4_bn = nn.BatchNorm3d(64)
        self.Conv_4_mp = nn.MaxPool3d(3)
        self.dense_1 = nn.Linear(2304, 128)
        self.dense_2 = nn.Linear(128, 2)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout2)

    def forward(self, x):
        #print("conv input_x.shape= ", np.shape(x))
        #print("self.Conv_1(x).shape= ", np.shape(self.Conv_1(x)))
        #print("self.Conv_1_bn(x).shape= ", np.shape(self.Conv_1_bn(self.Conv_1(x))))
        x = self.relu(self.Conv_1_bn(self.Conv_1(x)))
        x = self.Conv_1_mp(x)
        #print("self.Conv_1_mp(x).shape= ", np.shape(self.Conv_1_mp(x)))
        
        #print("self.Conv_2(x).shape= ", np.shape(self.Conv_2(x)))
        #print("self.Conv_2_bn(x).shape= ", np.shape(self.Conv_2_bn(self.Conv_2(x))))
        #print("self.Conv_2_mp(x).shape= ", np.shape(self.Conv_2_mp(x)))
        x = self.relu(self.Conv_2_bn(self.Conv_2(x)))
        x = self.Conv_2_mp(x)
        x = self.relu(self.Conv_3_bn(self.Conv_3(x)))
        x = self.Conv_3_mp(x)
        x = self.relu(self.Conv_4_bn(self.Conv_4(x)))
        x = self.Conv_4_mp(x)
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.relu(self.dense_1(x))
        x = self.dropout2(x)
        x = self.dense_2(x)
        return x


net = ClassificationModel3D().cuda(gpu)


print("Trainable model parameters: {}".format(count_parameters(net))) #输出网络的参数个数


# Training


num_epochs = 200
min_iters = 3
ignore_epochs = 15
normalize = False
retain_metric = accuracy_score
metrics = [accuracy_score]

r = 0


#=============================traing model==================

# models = []
# for i in range(1):
#     net = ClassificationModel3D()
#     net.load_state_dict(torch.load("./mymodel/close/" + 'LRP_best.pth'))
#     models.append(net)
# 
# test_loader = DataLoader(adni_data_test, batch_size=1, num_workers=0, shuffle=False)
# 
# metrics = []
# lr = 1e-5
# wd = 1e-3
# criterion = nn.BCEWithLogitsLoss().cuda(gpu)
# optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=wd)
# 
# for fold, model in enumerate(models):
#     print("Fold {}".format(fold))
# 
#     all_preds = []
#     all_labels = []
#     ridlist = []
#     viscodelist = []
# 
#     net = model.cuda(gpu)
#     net.eval()
#     with torch.no_grad():
#         for sample in test_loader:
#             img = sample["image"]
#             label = sample["label"]
#             rid = sample['rid']
#             viscode = sample['viscode']
# 
#             img = img.to(torch.device("cuda:" + str(gpu)))
#             # output = net.forward(img)
#             output, out3 = net.forward(img)
# 
#             # pred = torch.argmax(F.softmax(output, dim=1))
#             # all_preds.append(pred.cpu().numpy().item())
#             # all_labels.append(label.numpy().item())
#             for rid_i, viscode_i, pred_i, label_i in zip(rid, viscode, output, label):
#                 rid_i = np.array(rid_i.cpu().detach())
#                 viscode_i = viscode_i
#                 pred_i = np.array(pred_i.cpu().detach())
#                 label_i = np.array(label_i.cpu().detach())
# 
#                 ridlist.append(rid_i[0])
#                 viscodelist.append(viscode_i)
#                 all_preds.append([pred_i[0], pred_i[1]])
#                 all_labels.append([label_i[0], label_i[1]])
# 
# 
#     balanced_acc = balanced_accuracy(all_labels, all_preds)
#     print(balanced_acc)
#     '''trainer = Trainer(
#                 net,
#                 criterion,
#                 optimizer,
#                 scheduler=None,
#                 metrics=metrics,
#                 callbacks=None,
#                 device=gpu,
#                 prediction_type="binary"
#             )
#     computed_metrics = trainer.evaluate_model(test_loader, metrics=[balanced_accuracy])'''
#     net.train()
#     metrics.append(balanced_acc)
# print("######## Final results ########")
# metrics_df = pd.DataFrame(metrics)
# print(metrics_df)
# print("Balanced accuracy mean {:.2f} %".format(np.mean(metrics_df[0]) * 100))
# 




#=========model test================

models = []
for i in range(1):
    net = ClassificationModel3D()
    net.load_state_dict(torch.load("./mymodel/" + 'LRP_best.pth'))
    models.append(net)
 
test_loader = DataLoader(adni_data_test, batch_size=1, num_workers=0, shuffle=False)
metrics = []
lr = 1e-5
wd = 1e-3
criterion = nn.BCEWithLogitsLoss().cuda(gpu)
optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=wd)

acc_list = []
for fold, model in enumerate(models):
    print("Fold {}".format(fold))
 
    all_preds = []
    all_labels = []
 
    net = model.cuda(gpu)
    net.eval()
    with torch.no_grad():
         for sample in test_loader:
             img = sample["image"]
             label = sample["label"]
# 
             img = img.to(torch.device("cuda:" + str(gpu)))
             output = net.forward(img)
             # print("F.softmax(output, dim=1)= ", F.softmax(output, dim=1))
             pred = F.softmax(output, dim=1)
             # all_preds.append(pred.cpu().numpy().item())
             # all_labels.append(label.numpy().item())
             all_preds.append(pred.detach().cpu().numpy())
             all_labels.append(label.numpy().item())

    all_labels_numpy = []
    all_preds_numpy = []

    for i in range(len(all_labels)):
        all_labels_numpy.append(np.array(all_labels[i]))

    for j in range(len(all_preds)):
        all_preds_numpy.append(np.array(all_preds[j]))

    all_labels_numpy = np.array(all_labels_numpy)
    all_preds_numpy = np.array(all_preds_numpy)

    preds = all_preds_numpy[:, 0, :]
    # # evindex.cal_CI(preds, all_preds_numpy)
    evindex.cal_CI_plot_close(preds, all_labels_numpy)

