"""
Settings for re-running the experiments from the paper "Layer-wise
relevance propagation for explaining deep neural network decisions
in MRI-based Alzheimer’s disease classification".

Please note that you need to download the ADNI data from 
http://adni.loni.usc.edu/ and preprocess it using 
https://github.com/ANTsX/ANTs/blob/master/Scripts/antsRegistrationSyNQuick.sh

Please prepare the data, such that you will get three HDF5 files,
consisting of a training, a validation and a holdout (test) set.
Each HDF5 file is required to have 2 datasets, namely X and y,
containing the data matrix and label vector accordingly. We have
included the "Data Split ADNI.ipynb" file as a guideline for data splitting.
Please note that it is highly dependent on the format of your data storage
and needs to be individualized as such. 

Furthermore you will need SPM12 https://www.fil.ion.ucl.ac.uk/spm/software/spm12/
in order to access the Neuromorphometrics atlas.

Arguments:
    model_path: Path to the trained pytorch model parameters 训练的pytorch模型参数的路径
    data_path: Path where the outputs will be stored and retrieved 存储和检索输出的路径
    ADNI_DIR: Path to the root of your downloaded ADNI data 指向下载的 ADNI 数据根目录的路径
    train_h5: Path to the training set HDF5 file 训练集 HDF5 文件的路径
    val_h5: Path to the validation set HDF5 file 验证集 HDF5 文件的路径
    holdout_h5: Path to the holdout set HDF5 file 测试集 HDF5 文件的路径
    binary_brain_mask: Path to the mask used for masking the images, included in the repository. 用于遮罩图像的蒙版的路径，包含在存储库中。
    nmm_mask_path: Path to the Neuromorphometrics mask. Needs to be acquired from SPM12. Typically located under ~/spm12/tpm/labels_Neuromorphometrics.nii 神经形态测量学掩模的路径。需要从 SPM12 获取
    nmm_mask_path_scaled: Path to the rescaled Neuromorphometrics mask. 重新缩放的神经形态测量模板的路径。


"""

settings = {
    "model_path": "/root/workspace/lxs/Pytorch-LRP-master/mymodel/LRP",
    "data_path": "/root/workspace/lxs/Pytorch-LRP-master/data/",
    "ADNI_DIR": "/root/workspace/lxs/ADNI/npy/",
    "train_h5": "/root/workspace/lxs/Pytorch-LRP-master/csv/train.csv",
    "val_h5": "/root/workspace/lxs/Pytorch-LRP-master/csv/valid.csv",
    "holdout_h5": "/root/workspace/lxs/Pytorch-LRP-master/csv/test.csv",
    "binary_brain_mask": "binary_brain_mask.nii.gz",
    "nmm_mask_path": "~/spm12/tpm/labels_Neuromorphometrics.nii",
    "nmm_mask_path_scaled": "nmm_mask_rescaled.nii"
}
