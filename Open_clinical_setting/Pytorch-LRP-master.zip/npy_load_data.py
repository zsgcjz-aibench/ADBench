import glob
import random
import os
import numpy as np
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms
import pandas as pd
import torch
from nitorch.transforms import ToTensor, SagittalTranslate, SagittalFlip, \
                                AxialTranslate, normalization_factors, Normalize, \
                                IntensityRescale

class ImageDataset(Dataset):
    def __init__(self,  transforms_1=None, transforms_2=None, csvpath= '', num_classes=2):
        self.transform1 = transforms.Compose([transforms_1])
        self.transform2 = transforms.Compose([transforms_2])
        self.csvpath = csvpath
        self.num_classes = num_classes 

        self.data_h5_ = pd.read_csv(self.csvpath)

        self.filename = self.data_h5_["filename"].values
        self.status = self.data_h5_["status"].values
        self.rids = self.data_h5_["RID"].values
        self.viscodes = self.data_h5_["VISCODE"].values



    def __getitem__(self, index):
        seed = np.random.randint(2147483647)  # make a seed with numpy generator
        random.seed(seed)  # apply this seed to img tranfsorms
        
        data_path = "/home/lxs/ncomms2022-main--datastore/MRI_process/test_data/processed/npy/"
        #print("self.filename[index % len(self.filename)]= ", str(self.filename[index % len(self.filename)]) + ".npy")

        x_train=self.transform1(np.load(data_path + str(self.filename[index % len(self.filename)]) + ".npy").astype(np.float32))

        y_train= self.status[index % len(self.status)]
        
        rid = self.rids[index % len(self.rids)]
        viscode = self.viscodes[index % len(self.viscodes)]

        label_tensor = np.zeros(shape=(self.num_classes,))
        # label = y_train >= 0.5
        if y_train == 0:
            label = 0
        elif y_train == 1:
            label = 1
        else:
            label = 2
            
        label = torch.LongTensor([label])
        rid = torch.LongTensor([rid])
        viscode = viscode
        
        
        # return {'A': item_A, 'B': item_B}

        return {'image':x_train,'label':label, 'rid':rid, 'viscode':viscode}
        # return {'image':x_train,'label':label}

    def __len__(self):
        return max(len(self.filename), len(self.status), len(self.rids), len(self.viscodes))
        # return max(len(self.filename), len(self.status))


