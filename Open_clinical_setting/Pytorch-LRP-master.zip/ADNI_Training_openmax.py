#!/usr/bin/env python
# coding: utf-8

import glob
import h5py
import os
import sys
import time
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import copy as cp
# pytorch
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler

# sklearn functions
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, KFold, GroupShuffleSplit

# load functions from nitorch
from nitorch.data import load_nifti
from nitorch.transforms import ToTensor, SagittalTranslate, SagittalFlip, \
                                AxialTranslate, normalization_factors, Normalize, \
                                IntensityRescale
from nitorch.callbacks import EarlyStopping, ModelCheckpoint
from nitorch.trainer import Trainer
from nitorch.initialization import weights_init
from nitorch.metrics import balanced_accuracy, sensitivity, specificity
from nitorch.utils import count_parameters
#import torchio as tio
from npy_load_data import ImageDataset
from scipy import stats
from sklearn.metrics import roc_auc_score
import eval_index_cal as evindex
import copy


from settings import settings
for k in settings.keys():
    print("Adding " + k + " to namespace")
    globals()[k] = settings[k]


torch.__version__

gpu = 2
b = 4 #banch_size
num_classes = 2

dtype = np.float64





train_h5_ = './csv/train.csv'
val_h5_ = './csv/valid.csv'
holdout_h5_ = './csv/test.csv'
open_test = './csv/open_test.csv'


adni_data_train = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=train_h5_)
adni_data_val = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=val_h5_)
adni_data_test = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=holdout_h5_)

adni_data_open_test = ImageDataset(transforms_1=ToTensor(), transforms_2=ToTensor(), csvpath=open_test)





class ClassificationModel3D(nn.Module):
    """The model we use in the paper."""

    def __init__(self, dropout=0.4, dropout2=0.4):
        nn.Module.__init__(self)
        self.Conv_1 = nn.Conv3d(1, 8, 3)
        self.Conv_1_bn = nn.BatchNorm3d(8)
        self.Conv_1_mp = nn.MaxPool3d(2)
        self.Conv_2 = nn.Conv3d(8, 16, 3)
        self.Conv_2_bn = nn.BatchNorm3d(16)
        self.Conv_2_mp = nn.MaxPool3d(3)
        self.Conv_3 = nn.Conv3d(16, 32, 3)
        self.Conv_3_bn = nn.BatchNorm3d(32)
        self.Conv_3_mp = nn.MaxPool3d(2)
        self.Conv_4 = nn.Conv3d(32, 64, 3)
        self.Conv_4_bn = nn.BatchNorm3d(64)
        self.Conv_4_mp = nn.MaxPool3d(3)
        self.dense_1 = nn.Linear(2304, 128)
        #close setting
        self.dense_2 = nn.Linear(128, 2)
        self.relu = nn.ReLU()
        #ovrns setting
        # self.out1 = nn.Linear(128, 1)
        # self.out2 = nn.Linear(128, 1)

        self.ac_out = nn.Sigmoid()

        self.dropout = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout2)

    def forward(self, x):
        # print("x.data= ", x.data)
        # print("x.type= ", type(x))
        x = self.relu(self.Conv_1_bn(self.Conv_1(x)))
        x = self.Conv_1_mp(x)

        x = self.relu(self.Conv_2_bn(self.Conv_2(x)))
        x = self.Conv_2_mp(x)
        x = self.relu(self.Conv_3_bn(self.Conv_3(x)))
        x = self.Conv_3_mp(x)
        x = self.relu(self.Conv_4_bn(self.Conv_4(x)))
        x = self.Conv_4_mp(x)
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.relu(self.dense_1(x))
        x = self.dropout2(x)
        #close setting
        x = self.dense_2(x)
        x = self.ac_out(x)
        #ovrns setting
        # out1 = self.out1(x)
        # out2 = self.out2(x)
        # out3 = torch.cat((out1, out2), dim=1)
        # x = self.ac_out(out3)


        # print(type(x))
        # print(x.shape)
        # return x, out3

        return x


net = ClassificationModel3D().cuda(gpu)


print("Trainable model parameters: {}".format(count_parameters(net))) #输出网络的参数个数


# Training
def run(
        net,
        data,
        shape,
        callbacks=[],
        augmentations=[],
        masked=False,
        metrics=[],
        k_folds=None,
        b=4,
        num_epochs=35,
        retain_metric=None
):
    fold_metric = []
    models = []
    fold = 0
    initial_prepend = None

    for trial in range(1):
        print("Starting trial {}".format(trial))

        # add current fold number to model checkpoint path
        if callbacks is not None:
            for idx, callback in enumerate(callbacks):
                if isinstance(callback, ModelCheckpoint):
                    if initial_prepend is None:
                        initial_prepend = callbacks[idx].prepend
                    callbacks[idx].prepend = initial_prepend + "cv_fold_{}_".format(fold)
        fold += 1

        # restart model
        del net
        net = ClassificationModel3D().cuda(gpu)

        # reset hyperparameters
        lr = 1e-4
        wd = 1e-4
        criterion = nn.CrossEntropyLoss().cuda(gpu)

        optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=wd)

        train_loader = DataLoader(
            adni_data_train, batch_size=b, num_workers=0, shuffle=True
        )
        val_loader = DataLoader(
            adni_data_val, batch_size=1, num_workers=0, shuffle=True
        )


        trainer = Trainer(
            net,
            criterion,
            optimizer,
            metrics=metrics,
            callbacks=callbacks,
            device=gpu,
            prediction_type="classification"
        )
        # train model and store results
        net, report = trainer.train_model(
            train_loader,
            val_loader,
            num_epochs=num_epochs,
            show_train_steps=60,
            show_validation_epochs=1
        )
        # append validation score of the retain metric
        if isinstance(retain_metric, str):
            fold_metric.append(report["val_metrics"][retain_metric][-1])
        else:
            fold_metric.append(report["val_metrics"][retain_metric.__name__][-1])

        models.append(net)
        print("Finished fold.")

        # visualize result
        # trainer.visualize_training(report, metrics)
        # trainer.evaluate_model(val_loader, gpu)

    torch.save(report["best_model"].state_dict(),
               "./mymodel/close/" + 'LRP_best.pth')
    print("################################")
    print("################################")
    print("All accuracies: {}".format(fold_metric))
    return fold_metric, models

features_in_hook = []
features_out_hook = []

# 使用 hook 函数
def hook(module, fea_in, fea_out):
    fea_in_np = fea_in[0].cpu().numpy()
    features_in_hook.append(fea_in_np)  # 勾的是指定层的输入.data
    # 只取前向传播的数值
    fea_out_np = list(fea_out[0].cpu().numpy())
    features_out_hook.append(fea_out_np)  # 勾的是指定层的输出.data
    return None

def get_av_softmax(test_loader, layer_name):
    net = ClassificationModel3D()
    net.load_state_dict(torch.load("./mymodel/close/" + 'LRP_best.pth'))
    for (name, module) in net.named_modules():
        # print(name)
        if name == layer_name:
            module.register_forward_hook(hook=hook)

    net = net.cuda(gpu)
    net.eval()
    ridlist = []
    viscodelist = []
    with torch.no_grad():
        for sample in test_loader:
            img = sample["image"]
            label = sample["label"]
            rid = sample['rid']
            viscode = sample['viscode']
            img = img.to(torch.device("cuda:" + str(gpu)))
            net(img)

            for rid_i, viscode_i in zip(rid, viscode):
                rid_i = np.array(rid_i.cpu().detach())
                viscode_i = viscode_i

                ridlist.append(rid_i[0])
                viscodelist.append(viscode_i)
            
    ridlist = np.array(ridlist)
    viscodelist = np.array(viscodelist)
    features_out_hook_np = cp.deepcopy(features_out_hook)
    features_out_hook_np = np.array(features_out_hook_np)
    print(np.shape(features_out_hook_np))  # 勾的是指定层的输入

    result = pd.DataFrame(ridlist, columns=['RID']) 
    result['VISCODE'] = viscodelist
    result['av1'] = features_out_hook_np[:, 0]
    result['av2'] = features_out_hook_np[:, 1]
    # print("result.shape= ", np.shape(result))

    result.to_csv('./close_train_valid_preds/openmax/Pytorch-LRP-master_train_av.csv', index=0)

    
num_epochs = 200
min_iters = 3
ignore_epochs = 15
normalize = False
retain_metric = accuracy_score
metrics = [accuracy_score]

r = 0
model_path = './mymodel/close'

#=============================traing model==================

models = []
for i in range(1):
    net = ClassificationModel3D()
    net.load_state_dict(torch.load("./mymodel/close/" + 'LRP_best.pth'))
    models.append(net)

test_loader = DataLoader(adni_data_test, batch_size=1, num_workers=0, shuffle=False)

metrics = []
lr = 1e-5
wd = 1e-3
criterion = nn.BCEWithLogitsLoss().cuda(gpu)
optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=wd)

for fold, model in enumerate(models):
    print("Fold {}".format(fold))

    all_preds = []
    all_labels = []
    ridlist = []
    viscodelist = []

    net = model.cuda(gpu)
    net.eval()
    with torch.no_grad():
        for sample in test_loader:
            img = sample["image"]
            label = sample["label"]
            rid = sample['rid']
            viscode = sample['viscode']

            img = img.to(torch.device("cuda:" + str(gpu)))
            # output = net.forward(img)
            output, out3 = net.forward(img)

            # pred = torch.argmax(F.softmax(output, dim=1))
            # all_preds.append(pred.cpu().numpy().item())
            # all_labels.append(label.numpy().item())
            for rid_i, viscode_i, pred_i, label_i in zip(rid, viscode, output, label):
                rid_i = np.array(rid_i.cpu().detach())
                viscode_i = viscode_i
                pred_i = np.array(pred_i.cpu().detach())
                label_i = np.array(label_i.cpu().detach())

                ridlist.append(rid_i[0])
                viscodelist.append(viscode_i)
                all_preds.append([pred_i[0], pred_i[1]])
                all_labels.append([label_i[0], label_i[1]])


    balanced_acc = balanced_accuracy(all_labels, all_preds)
    print(balanced_acc)
    '''trainer = Trainer(
                net,
                criterion,
                optimizer,
                scheduler=None,
                metrics=metrics,
                callbacks=None,
                device=gpu,
                prediction_type="binary"
            )
    computed_metrics = trainer.evaluate_model(test_loader, metrics=[balanced_accuracy])'''
    net.train()
    metrics.append(balanced_acc)
print("######## Final results ########")
metrics_df = pd.DataFrame(metrics)
print(metrics_df)
print("Balanced accuracy mean {:.2f} %".format(np.mean(metrics_df[0]) * 100))




#==========================model test==================================
models = []
for i in range(1):
    net = ClassificationModel3D()
    net.load_state_dict(torch.load("./mymodel/close/" + 'LRP_best.pth'))
    models.append(net)

test_loader = DataLoader(adni_data_train, batch_size=1, num_workers=0, shuffle=False) #close场景
layer_name = 'dense_2'
get_av_softmax(test_loader, layer_name)
# # test_loader = DataLoader(adni_data_open_test, batch_size=1, num_workers=0, shuffle=False) #thr场景
metrics = []
lr = 1e-5
wd = 1e-3
criterion = nn.BCEWithLogitsLoss().cuda(gpu)
optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=wd)

acc_list = []
for fold, model in enumerate(models):
    print("Fold {}".format(fold))

    all_preds = []
    all_labels = []

    ridlist = []
    viscodelist = []

    net = model.cuda(gpu)
    net.eval()
    with torch.no_grad():
        for sample in test_loader:
            img = sample["image"]
            label = sample["label"]
            rid = sample['rid']
            viscode = sample['viscode']
            #
            img = img.to(torch.device("cuda:" + str(gpu)))
            output = net.forward(img)

            pred = output

            for rid_i, viscode_i, pred_i, label_i in zip(rid, viscode, output, label):
                rid_i = np.array(rid_i.cpu().detach())
                viscode_i = viscode_i
                pred_i = np.array(pred_i.cpu().detach())
                label_i = np.array(label_i.cpu().detach())

                ridlist.append(rid_i[0])
                viscodelist.append(viscode_i)
                all_preds.append([pred_i[0], pred_i[1]])
                all_labels.append(label_i[0])


    ridlist = np.array(ridlist)
    viscodelist = np.array(viscodelist)
    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)


    result = pd.DataFrame(ridlist, columns=['RID']) #, 'VISCODE', 'pred_cn', 'pred_ad', 'label'
    result['VISCODE'] = viscodelist
    result['s1'] = all_preds[:, 0]
    result['s2'] = all_preds[:, 1]
    result['label'] = all_labels

    # print("result.shape= ", np.shape(result))

    result.to_csv('./close_train_valid_preds/openmax/Pytorch-LRP-master_train_preds.csv', index=0)
    # evindex.cal_CI_plot(all_preds, all_labels)  #thr setting
    # evindex.cal_CI_plot_close3(all_preds, all_labels)  #close setting






